# encoding: UTF-8

require 'common/collections/vulnerabilities/output'

class Vulnerabilities < Array
  include Vulnerabilities::Output

end
