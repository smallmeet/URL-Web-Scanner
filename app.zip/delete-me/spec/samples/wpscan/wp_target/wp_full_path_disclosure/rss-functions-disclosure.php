<html><head>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1"></head><body><br>
<font size="1"><table class="xdebug-error" dir="ltr" border="1" cellpadding="1" cellspacing="0">
<tbody><tr><th colspan="5" align="left" bgcolor="#f57900"><span style="background-color: #cc0000; color: #fce94f; font-size: x-large;">( ! )</span>
 Fatal error: Call to undefined function _deprecated_file() in 
/home/web/www/blog/wordpress/wp-includes/rss-functions.php on line <i>8</i></th></tr>
<tr><th colspan="5" align="left" bgcolor="#e9b96e">Call Stack</th></tr>
<tr><th align="center" bgcolor="#eeeeec">#</th><th align="left" bgcolor="#eeeeec">Time</th><th align="left" bgcolor="#eeeeec">Memory</th><th align="left" bgcolor="#eeeeec">Function</th><th align="left" bgcolor="#eeeeec">Location</th></tr>
<tr><td align="center" bgcolor="#eeeeec">1</td><td align="center" bgcolor="#eeeeec">0.0000</td><td align="right" bgcolor="#eeeeec">630936</td><td bgcolor="#eeeeec">{main}(  )</td><td title="/home/web/www/blog/wordpress/wp-includes/rss-functions.php" bgcolor="#eeeeec">../rss-functions.php<b>:</b>0</td></tr>
</tbody></table></font>
</body></html>