<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\CurlController;
use App\Http\Controllers\UserDirController;
use App\Http\Controllers\Auth\RegisteredController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;




class ScanSecurityScanController extends Controller
{


    
     
    public function update(Request $request){

            $curl = new CurlController;
    	    $user_name = json_decode(Auth::user());
    	    $user_dir =  base_path("users\\") . $user_name->email;
    	    $filesystem = new Filesystem;
    	    $return_array =[];
    	    $server = '';
    	    $url = ''; 
    	    $wp_version = '';
            $wp_version_undetected = '';
    	    $scanurl = $request->scanurl;
            $ip = '';

             /***Ajax GET Parameters Request ***/
    	     $this->validate($request,
	          [
	          'scanurl'=>'required|url'
	          ]);

 
    	    $scan_response = $curl->curl_request('http://166.62.116.178/index.php?scanurl='.$scanurl.'');
    	    if(!file_put_contents($user_dir . "\scan_results.txt", $scan_response)){
    	    	Log::info("Error creating scanresults for user:: ");
    	    	die("Error creating scanresults for user::");
    	    }
             
            if(!$filesystem->isFile($user_dir . "\scan_results.txt")){
                     
                Log::info("Error " .$user_dir . "\scan_results.txt" . " Does Not Exist");
    	    	die("Error  scanresults.txt does not exist for user::");
           }

    	   $file =file($user_dir . "\scan_results.txt");

           for($i=0; $i < count($file); $i++) {

                    
                  if(strrpos($file[$i], "WordPress version can not be detected") !==false){
                      $wp_version_undetected = $file[$i];
                 } 
                 
                  $wp_version_undetected_arr = explode(" ", $wp_version_undetected);
               

                 if(strrpos($file[$i], "WordPress version") !==false){
                 	  $wp_version = $file[$i];
                 } 
                 
                  $wp_version_arr = explode(" ", $wp_version);

                  if(strrpos($file[$i], "Interesting header: SERVER:") !==false){
                      $server = $file[$i];
                     
                 } 

                  $parse_url = parse_url($request->scanurl,PHP_URL_HOST);
                  $parse_url = "www." .$parse_url;
                  $server_arr = explode(" ", $server);

                  if(isset($wp_version_arr[3]) && isset($server_arr[4]) or isset($wp_version_undetected_arr[1]) 
                    or isset($wp_version_undetected_arr[2]) or isset($wp_version_undetected_arr[3]) 
                    or isset($wp_version_undetected_arr[4]) or isset($wp_version_undetected_arr[5])
                    or isset($wp_version_undetected_arr[6]) ){
                     
                     if(!$ip = gethostbyname($parse_url)){
                      Log::info("Error " .$parse_url . " is not a correct host");
                      die("Error " .$parse_url . " is not a correct host");
                     }


                      $results = array(
                            'url' =>$parse_url,
                            'wp_version'=>$wp_version_arr[3],
                            'server'=>$server_arr[4],
                            'ip'=>$ip,
                            'wp_version_undetected'=>$wp_version_undetected_arr[1] .' '. $wp_version_undetected_arr[2].' '.
                            $wp_version_undetected_arr[3] .' '. $wp_version_undetected_arr[4].' '.$wp_version_undetected_arr[5].' '. $wp_version_undetected_arr[6]
                     );
                   
                  }
                     
                  
           }
                      array_push($return_array, $results); 
                    echo json_encode($return_array);






          //Log::info("Error in executing process");
    	   //$return_array = array('url' => $url,'server'=>$server);
	      //         echo json_encode($return_array);
	      //         echo "TEST";
          // $user_decode = json_decode(Auth::user());
    	  // return $user_dir; 



    }



  


}
